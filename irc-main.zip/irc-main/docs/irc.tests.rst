irc.tests package
=================

Submodules
----------

irc.tests.test_bot module
-------------------------

.. automodule:: irc.tests.test_bot
    :members:
    :undoc-members:
    :show-inheritance:

irc.tests.test_client module
----------------------------

.. automodule:: irc.tests.test_client
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: irc.tests
    :members:
    :undoc-members:
    :show-inheritance:
